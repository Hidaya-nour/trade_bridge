import api from './api';

class FeedbackService {
  async getAll(params?: any) {
    const response = await api.get('/feedbacks', { params });
    return response.data;
  }

  async getById(id: string) {
    const response = await api.get(`/feedbacks/${id}`);
    return response.data;
  }

  async create(data: any) {
    const response = await api.post('/feedbacks', data);
    return response.data;
  }

  async update(id: string, data: any) {
    const response = await api.put(`/feedbacks/${id}`, data);
    return response.data;
  }

  async delete(id: string) {
    const response = await api.delete(`/feedbacks/${id}`);
    return response.data;
  }
}

export default new FeedbackService();
